const { Pool } = require('pg');
const secretManager = require('./secretManager');

class DatabaseService {
    constructor() {
        this.pool = null;
    }

    async initializeConnection() {
        try {
            const dbCredentials = await secretManager.getSecret('samsung-sso-db-credentials');
            
            this.pool = new Pool({
                user: dbCredentials.username,
                host: dbCredentials.host,
                database: dbCredentials.database,
                password: dbCredentials.password,
                port: dbCredentials.port
            });

            // Test connection
            const client = await this.pool.connect();
            client.release();
            console.log('Database connection successful');
        } catch (err) {
            console.error('Database connection error:', err);
            throw err;
        }
    }

    async insertUser(userData) {
        const client = await this.pool.connect();
        try {
            const query = `
                INSERT INTO users 
                (samsung_id, email, name, access_token, refresh_token) 
                VALUES ($1, $2, $3, $4, $5) 
                ON CONFLICT (samsung_id) DO UPDATE 
                SET email = $2, name = $3, access_token = $4, refresh_token = $5
                RETURNING *
            `;
            const values = [
                userData.samsungId, 
                userData.email, 
                userData.name, 
                userData.accessToken, 
                userData.refreshToken
            ];

            const result = await client.query(query, values);
            return result.rows[0];
        } finally {
            client.release();
        }
    }

    async getUserBySamsungId(samsungId) {
        const client = await this.pool.connect();
        try {
            const query = 'SELECT * FROM users WHERE samsung_id = $1';
            const result = await client.query(query, [samsungId]);
            return result.rows[0];
        } finally {
            client.release();
        }
    }

    async updateUserTokens(samsungId, accessToken, refreshToken) {
        const client = await this.pool.connect();
        try {
            const query = `
                UPDATE users 
                SET access_token = $2, refresh_token = $3 
                WHERE samsung_id = $1
                RETURNING *
            `;
            const result = await client.query(query, [samsungId, accessToken, refreshToken]);
            return result.rows[0];
        } finally {
            client.release();
        }
    }
}

module.exports = new DatabaseService();
