const Redis = require('redis');
const { promisify } = require('util');

class RedisService {
    constructor() {
        this.client = Redis.createClient({
            host: process.env.REDIS_HOST || 'localhost',
            port: process.env.REDIS_PORT || 6379
        });

        this.client.on('error', (err) => {
            console.error('Redis Client Error', err);
        });

        // Promisify Redis methods
        this.setAsync = promisify(this.client.set).bind(this.client);
        this.getAsync = promisify(this.client.get).bind(this.client);
        this.delAsync = promisify(this.client.del).bind(this.client);
    }

    async set(key, value, expiry = null) {
        try {
            if (expiry) {
                return await this.setAsync(key, JSON.stringify(value), 'EX', expiry);
            }
            return await this.setAsync(key, JSON.stringify(value));
        } catch (err) {
            console.error('Redis set error:', err);
            throw err;
        }
    }

    async get(key) {
        try {
            const value = await this.getAsync(key);
            return value ? JSON.parse(value) : null;
        } catch (err) {
            console.error('Redis get error:', err);
            throw err;
        }
    }

    async delete(key) {
        try {
            return await this.delAsync(key);
        } catch (err) {
            console.error('Redis delete error:', err);
            throw err;
        }
    }
}

module.exports = new RedisService();
