const AWS = require('aws-sdk');

class SecretManagerService {
    constructor() {
        this.secretsManager = new AWS.SecretsManager({
            region: process.env.AWS_REGION || 'us-east-1'
        });
    }

    async getSecret(secretName) {
        try {
            const data = await this.secretsManager.getSecretValue({ SecretId: secretName }).promise();
            
            if ('SecretString' in data) {
                return JSON.parse(data.SecretString);
            }
            
            throw new Error('Secret not found');
        } catch (err) {
            console.error('Error retrieving secret:', err);
            throw err;
        }
    }
}

module.exports = new SecretManagerService();
