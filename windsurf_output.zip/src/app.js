require('dotenv').config();
const express = require('express');
const cors = require('cors');
const databaseService = require('./services/databaseService');
const redisService = require('./services/redisService');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/auth', authRoutes);

// Initialize services
async function initializeServices() {
    try {
        await databaseService.initializeConnection();
        console.log('Database service initialized');
    } catch (error) {
        console.error('Failed to initialize database service:', error);
    }
}

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    initializeServices();
});

module.exports = { 
    app, 
    initializeServices 
};
