const express = require('express');
const axios = require('axios');
const redisService = require('../services/redisService');
const databaseService = require('../services/databaseService');
const secretManager = require('../services/secretManager');

const router = express.Router();

router.get('/login', async (req, res) => {
    try {
        const samsungConfig = await secretManager.getSecret('samsung-sso-config');
        const authorizationUrl = `https://account.samsung.com/accounts/oauth2/authorize?client_id=${samsungConfig.clientId}&redirect_uri=${samsungConfig.callbackUrl}&response_type=code&scope=profile`;
        
        res.redirect(authorizationUrl);
    } catch (error) {
        res.status(500).json({ error: 'Authentication initialization failed' });
    }
});

router.get('/callback', async (req, res) => {
    try {
        const { code } = req.query;
        const samsungConfig = await secretManager.getSecret('samsung-sso-config');

        // Exchange authorization code for tokens
        const tokenResponse = await axios.post('https://account.samsung.com/accounts/oauth2/token', null, {
            params: {
                client_id: samsungConfig.clientId,
                client_secret: samsungConfig.clientSecret,
                code: code,
                grant_type: 'authorization_code',
                redirect_uri: samsungConfig.callbackUrl
            }
        });

        const { access_token, refresh_token } = tokenResponse.data;

        // Fetch user profile
        const profileResponse = await axios.get('https://account.samsung.com/accounts/userinfo', {
            headers: { Authorization: `Bearer ${access_token}` }
        });

        const userData = {
            samsungId: profileResponse.data.sub,
            email: profileResponse.data.email,
            name: profileResponse.data.name,
            accessToken: access_token,
            refreshToken: refresh_token
        };

        // Save user data to database
        await databaseService.insertUser(userData);

        // Store tokens in Redis
        await redisService.set(`user:${userData.samsungId}:tokens`, {
            accessToken: access_token,
            refreshToken: refresh_token
        }, 3600 * 24 * 7); // 7 days expiry

        res.redirect(samsungConfig.frontendRedirectUrl);
    } catch (error) {
        console.error('Callback processing error:', error);
        res.status(500).json({ error: 'Authentication callback failed' });
    }
});

router.post('/logout', async (req, res) => {
    try {
        const { samsungId } = req.body;
        const samsungConfig = await secretManager.getSecret('samsung-sso-config');

        // Delete tokens from Redis
        await redisService.delete(`user:${samsungId}:tokens`);

        // Redirect to Samsung logout
        const logoutUrl = `https://account.samsung.com/accounts/logout?client_id=${samsungConfig.clientId}`;
        
        res.json({ logoutUrl });
    } catch (error) {
        res.status(500).json({ error: 'Logout failed' });
    }
});

module.exports = router;
