const request = require('supertest');
const express = require('express');
const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');

const authRoutes = require('../src/routes/authRoutes');
const redisService = require('../src/services/redisService');
const databaseService = require('../src/services/databaseService');
const secretManager = require('../src/services/secretManager');

// Create a mock for axios
const axiosMock = new MockAdapter(axios);

// Mock dependencies
jest.mock('../src/services/redisService');
jest.mock('../src/services/databaseService');
jest.mock('../src/services/secretManager');

describe('Authentication Routes', () => {
    let app;
    let mockSecretConfig;

    beforeEach(() => {
        app = express();
        app.use(express.json());
        app.use('/auth', authRoutes);

        mockSecretConfig = {
            clientId: 'test_client_id',
            clientSecret: 'test_client_secret',
            callbackUrl: 'http://localhost:3000/auth/callback',
            frontendRedirectUrl: 'http://localhost:3000/dashboard'
        };

        secretManager.getSecret.mockResolvedValue(mockSecretConfig);
    });

    afterEach(() => {
        axiosMock.reset();
        jest.clearAllMocks();
    });

    describe('GET /auth/login', () => {
        test('should redirect to Samsung authorization URL', async () => {
            const response = await request(app).get('/auth/login');
            
            expect(response.statusCode).toBe(302);
            expect(response.headers.location).toContain('https://account.samsung.com/accounts/oauth2/authorize');
            expect(response.headers.location).toContain(`client_id=${mockSecretConfig.clientId}`);
        });
    });

    describe('GET /auth/callback', () => {
        test('should handle successful authentication', async () => {
            const mockCode = 'test_auth_code';
            const mockTokenResponse = {
                access_token: 'test_access_token',
                refresh_token: 'test_refresh_token'
            };
            const mockUserProfile = {
                sub: 'samsung123',
                email: 'test@example.com',
                name: 'Test User'
            };

            // Mock token exchange
            axiosMock.onPost('https://account.samsung.com/accounts/oauth2/token')
                .reply(200, mockTokenResponse);

            // Mock user profile fetch
            axiosMock.onGet('https://account.samsung.com/accounts/userinfo')
                .reply(200, mockUserProfile);

            // Mock database and redis services
            databaseService.insertUser.mockResolvedValue(mockUserProfile);
            redisService.set.mockResolvedValue('OK');

            const response = await request(app)
                .get(`/auth/callback?code=${mockCode}`);

            expect(response.statusCode).toBe(302);
            expect(response.headers.location).toBe(mockSecretConfig.frontendRedirectUrl);

            // Verify interactions
            expect(databaseService.insertUser).toHaveBeenCalledWith(expect.objectContaining({
                samsungId: mockUserProfile.sub,
                email: mockUserProfile.email,
                name: mockUserProfile.name
            }));
            expect(redisService.set).toHaveBeenCalledWith(
                `user:${mockUserProfile.sub}:tokens`,
                expect.objectContaining({
                    accessToken: mockTokenResponse.access_token,
                    refreshToken: mockTokenResponse.refresh_token
                }),
                expect.any(Number)
            );
        });

        test('should handle authentication failure', async () => {
            axiosMock.onPost('https://account.samsung.com/accounts/oauth2/token')
                .reply(400, { error: 'Invalid authorization code' });

            const response = await request(app)
                .get('/auth/callback?code=invalid_code');

            expect(response.statusCode).toBe(500);
            expect(response.body.error).toBe('Authentication callback failed');
        });
    });

    describe('POST /auth/logout', () => {
        test('should handle user logout', async () => {
            const samsungId = 'samsung123';

            redisService.delete.mockResolvedValue(1);

            const response = await request(app)
                .post('/auth/logout')
                .send({ samsungId });

            expect(response.statusCode).toBe(200);
            expect(response.body.logoutUrl).toContain('https://account.samsung.com/accounts/logout');
            expect(redisService.delete).toHaveBeenCalledWith(`user:${samsungId}:tokens`);
        });

        test('should handle logout failure', async () => {
            const samsungId = 'samsung123';

            redisService.delete.mockRejectedValue(new Error('Redis error'));

            const response = await request(app)
                .post('/auth/logout')
                .send({ samsungId });

            expect(response.statusCode).toBe(500);
            expect(response.body.error).toBe('Logout failed');
        });
    });
});
