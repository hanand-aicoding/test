const Redis = require('redis');
const redisService = require('../src/services/redisService');

// Mock Redis client
jest.mock('redis', () => {
    const mClient = {
        set: jest.fn(),
        get: jest.fn(),
        del: jest.fn(),
        on: jest.fn()
    };
    return {
        createClient: jest.fn(() => mClient)
    };
});

describe('RedisService', () => {
    let mockRedisClient;

    beforeEach(() => {
        mockRedisClient = Redis.createClient();
    });

    test('should set value in Redis with expiry', async () => {
        mockRedisClient.set.mockImplementation((key, value, mode, expiry, callback) => {
            callback(null, 'OK');
        });

        const result = await redisService.set('test-key', { data: 'test' }, 3600);
        expect(result).toBe('OK');
        expect(mockRedisClient.set).toHaveBeenCalledWith(
            'test-key', 
            JSON.stringify({ data: 'test' }), 
            'EX', 
            3600, 
            expect.any(Function)
        );
    });

    test('should set value in Redis without expiry', async () => {
        mockRedisClient.set.mockImplementation((key, value, callback) => {
            callback(null, 'OK');
        });

        const result = await redisService.set('test-key', { data: 'test' });
        expect(result).toBe('OK');
        expect(mockRedisClient.set).toHaveBeenCalledWith(
            'test-key', 
            JSON.stringify({ data: 'test' }), 
            expect.any(Function)
        );
    });

    test('should get value from Redis', async () => {
        const mockValue = { data: 'test' };
        mockRedisClient.get.mockImplementation((key, callback) => {
            callback(null, JSON.stringify(mockValue));
        });

        const result = await redisService.get('test-key');
        expect(result).toEqual(mockValue);
    });

    test('should return null when getting non-existent key', async () => {
        mockRedisClient.get.mockImplementation((key, callback) => {
            callback(null, null);
        });

        const result = await redisService.get('non-existent-key');
        expect(result).toBeNull();
    });

    test('should delete value from Redis', async () => {
        mockRedisClient.del.mockImplementation((key, callback) => {
            callback(null, 1);
        });

        const result = await redisService.delete('test-key');
        expect(result).toBe(1);
    });

    test('should handle Redis set error', async () => {
        mockRedisClient.set.mockImplementation((key, value, mode, expiry, callback) => {
            callback(new Error('Redis set error'));
        });

        await expect(redisService.set('test-key', { data: 'test' })).rejects.toThrow('Redis set error');
    });

    test('should handle Redis get error', async () => {
        mockRedisClient.get.mockImplementation((key, callback) => {
            callback(new Error('Redis get error'));
        });

        await expect(redisService.get('test-key')).rejects.toThrow('Redis get error');
    });

    test('should handle Redis delete error', async () => {
        mockRedisClient.del.mockImplementation((key, callback) => {
            callback(new Error('Redis delete error'));
        });

        await expect(redisService.delete('test-key')).rejects.toThrow('Redis delete error');
    });

    test('should log Redis client error', () => {
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
        const errorCallback = mockRedisClient.on.mock.calls[0][1];
        
        const testError = new Error('Test Redis error');
        errorCallback(testError);

        expect(consoleErrorSpy).toHaveBeenCalledWith('Redis Client Error', testError);
        consoleErrorSpy.mockRestore();
    });
});
