const { Pool } = require('pg');
const databaseService = require('../src/services/databaseService');
const secretManager = require('../src/services/secretManager');

// Mock dependencies
jest.mock('pg', () => {
    const mClient = {
        connect: jest.fn(),
        query: jest.fn(),
        release: jest.fn()
    };
    const mPool = {
        connect: jest.fn(() => mClient)
    };
    return { Pool: jest.fn(() => mPool) };
});

jest.mock('../src/services/secretManager', () => ({
    getSecret: jest.fn()
}));

describe('DatabaseService', () => {
    let mockPool;
    let mockClient;

    beforeEach(() => {
        mockPool = new Pool();
        mockClient = mockPool.connect();

        secretManager.getSecret.mockResolvedValue({
            username: 'testuser',
            host: 'localhost',
            database: 'testdb',
            password: 'testpass',
            port: 5432
        });
    });

    test('should initialize database connection', async () => {
        mockClient.connect.mockResolvedValue(mockClient);
        
        await databaseService.initializeConnection();
        expect(mockClient.connect).toHaveBeenCalled();
        expect(mockClient.release).toHaveBeenCalled();
    });

    test('should insert user', async () => {
        const userData = {
            samsungId: 'samsung123',
            email: 'test@example.com',
            name: 'Test User',
            accessToken: 'access_token',
            refreshToken: 'refresh_token'
        };

        mockClient.query.mockResolvedValue({
            rows: [{ ...userData }]
        });

        const result = await databaseService.insertUser(userData);
        expect(result).toEqual(userData);
        expect(mockClient.query).toHaveBeenCalledWith(
            expect.stringContaining('INSERT INTO users'),
            expect.any(Array)
        );
    });

    test('should get user by Samsung ID', async () => {
        const mockUser = {
            samsung_id: 'samsung123',
            email: 'test@example.com'
        };

        mockClient.query.mockResolvedValue({
            rows: [mockUser]
        });

        const result = await databaseService.getUserBySamsungId('samsung123');
        expect(result).toEqual(mockUser);
    });

    test('should update user tokens', async () => {
        const mockUpdatedUser = {
            samsung_id: 'samsung123',
            access_token: 'new_access_token',
            refresh_token: 'new_refresh_token'
        };

        mockClient.query.mockResolvedValue({
            rows: [mockUpdatedUser]
        });

        const result = await databaseService.updateUserTokens(
            'samsung123', 
            'new_access_token', 
            'new_refresh_token'
        );
        expect(result).toEqual(mockUpdatedUser);
    });

    test('should handle database connection error', async () => {
        mockClient.connect.mockRejectedValue(new Error('Connection failed'));

        await expect(databaseService.initializeConnection()).rejects.toThrow('Connection failed');
    });
});
