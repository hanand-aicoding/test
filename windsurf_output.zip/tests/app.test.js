const { app, initializeServices } = require('../src/app');
const databaseService = require('../src/services/databaseService');
const request = require('supertest');

// Mock dependencies
jest.mock('../src/services/databaseService', () => ({
    initializeConnection: jest.fn()
}));

describe('App Initialization', () => {
    let originalConsoleLog;
    let originalConsoleError;

    beforeEach(() => {
        originalConsoleLog = console.log;
        originalConsoleError = console.error;
        console.log = jest.fn();
        console.error = jest.fn();
    });

    afterEach(() => {
        console.log = originalConsoleLog;
        console.error = originalConsoleError;
        jest.clearAllMocks();
    });

    test('should initialize services successfully', async () => {
        databaseService.initializeConnection.mockResolvedValue();
        
        await initializeServices();
        
        expect(databaseService.initializeConnection).toHaveBeenCalled();
        expect(console.log).toHaveBeenCalledWith('Database service initialized');
    });

    test('should handle service initialization error', async () => {
        const mockError = new Error('Initialization failed');
        databaseService.initializeConnection.mockRejectedValue(mockError);
        
        await initializeServices();
        
        expect(databaseService.initializeConnection).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith('Failed to initialize database service:', mockError);
    });

    test('should have auth routes registered', async () => {
        const response = await request(app).get('/auth/login');
        expect(response.statusCode).not.toBe(404);
    });
});
