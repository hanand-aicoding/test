const AWS = require('aws-sdk');
const secretManager = require('../src/services/secretManager');

// Mock AWS.SecretsManager
jest.mock('aws-sdk', () => {
    const mSecretsManager = {
        getSecretValue: jest.fn()
    };
    return {
        SecretsManager: jest.fn(() => mSecretsManager)
    };
});

describe('SecretManagerService', () => {
    let mockSecretsManager;

    beforeEach(() => {
        mockSecretsManager = new AWS.SecretsManager();
    });

    test('should retrieve secret successfully', async () => {
        const mockSecret = { username: 'testuser', password: 'testpass' };
        mockSecretsManager.getSecretValue.mockReturnValue({
            promise: () => Promise.resolve({ SecretString: JSON.stringify(mockSecret) })
        });

        const result = await secretManager.getSecret('test-secret');
        expect(result).toEqual(mockSecret);
        expect(mockSecretsManager.getSecretValue).toHaveBeenCalledWith({ SecretId: 'test-secret' });
    });

    test('should throw error if secret retrieval fails', async () => {
        mockSecretsManager.getSecretValue.mockReturnValue({
            promise: () => Promise.reject(new Error('Retrieval failed'))
        });

        await expect(secretManager.getSecret('test-secret')).rejects.toThrow('Retrieval failed');
    });

    test('should throw error if secret is not a SecretString', async () => {
        mockSecretsManager.getSecretValue.mockReturnValue({
            promise: () => Promise.resolve({ SecretBinary: 'some-binary-data' })
        });

        await expect(secretManager.getSecret('test-secret')).rejects.toThrow('Secret not found');
    });
});
