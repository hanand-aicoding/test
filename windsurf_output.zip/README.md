# Samsung SSO Authentication Backend

## Prerequisites
- Node.js (v18+)
- PostgreSQL Database
- Redis
- AWS Account for Secrets Manager

## Setup
1. Clone the repository
2. Install dependencies: `npm install`
3. Configure AWS Secrets Manager with:
   - `samsung-sso-config`: Contains Samsung OAuth credentials
   - `samsung-sso-db-credentials`: Contains PostgreSQL connection details

## Environment Variables
- `PORT`: Server port
- `AWS_REGION`: AWS region for Secrets Manager
- `REDIS_HOST`: Redis server host
- `REDIS_PORT`: Redis server port

## Database Setup
Create users table:
```sql
CREATE TABLE users (
    samsung_id VARCHAR(255) PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    access_token TEXT,
    refresh_token TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Running the Server
`npm start`

## API Endpoints
- `/auth/login`: Initiate Samsung login
- `/auth/callback`: Handle Samsung OAuth callback
- `/auth/logout`: Logout user
