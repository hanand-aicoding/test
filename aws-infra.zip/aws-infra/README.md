# AWS Infra CDK Stack

This stack sets up the following AWS infrastructure:

- VPC with private subnets
- ECS Fargate services for SSO and Operations (4 vCPU, 8GB RAM each), behind an internal ALB with path-based routing
- 10 Lambda functions:
  - 8 triggered by API Gateway endpoints (api/v1/api1 to api/v1/api8)
  - 1 triggered by FIFO SQS queue (queue_1)
  - 1 triggered daily by a cron schedule (2am IST)
- All compute resources in private subnets
- All traffic routed via CloudFront distribution with proper behaviors for API calls

## Usage

1. Install dependencies:
   ```sh
   npm install
   ```
2. Synthesize the CloudFormation template:
   ```sh
   npx cdk synth
   ```
3. Deploy the stack:
   ```sh
   npx cdk deploy
   ```

## Notes
- Replace the ECS container images and Lambda code as per your application logic.
- Ensure your AWS credentials are set up before deploying.
