import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecs_patterns from 'aws-cdk-lib/aws-ecs-patterns';
import * as elbv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigw from 'aws-cdk-lib/aws-apigateway';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as origins from 'aws-cdk-lib/aws-cloudfront-origins';

export class AwsInfraStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // ----------------------
    // 1. VPC with security best practices
    // ----------------------
    const vpc = new ec2.Vpc(this, 'Vpc', {
      maxAzs: 2,
      natGateways: 1,
      subnetConfiguration: [
        { name: 'public', subnetType: ec2.SubnetType.PUBLIC },
        { name: 'private', subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      ],
    });
    // Example NACL (restrict all inbound except 443/80 from CloudFront and ephemeral outbound)
    const nacl = new ec2.NetworkAcl(this, 'AppNacl', { vpc });
    nacl.addEntry('AllowHTTP', {
      direction: ec2.TrafficDirection.INGRESS,
      ruleNumber: 100,
      cidr: ec2.AclCidr.anyIpv4(),
      ruleAction: ec2.Action.ALLOW,
      protocol: ec2.Protocol.TCP,
      fromPort: 80,
      toPort: 80,
    });
    nacl.addEntry('AllowHTTPS', {
      direction: ec2.TrafficDirection.INGRESS,
      ruleNumber: 110,
      cidr: ec2.AclCidr.anyIpv4(),
      ruleAction: ec2.Action.ALLOW,
      protocol: ec2.Protocol.TCP,
      fromPort: 443,
      toPort: 443,
    });
    nacl.addEntry('AllowEphemeral', {
      direction: ec2.TrafficDirection.EGRESS,
      ruleNumber: 120,
      cidr: ec2.AclCidr.anyIpv4(),
      ruleAction: ec2.Action.ALLOW,
      protocol: ec2.Protocol.TCP,
      fromPort: 1024,
      toPort: 65535,
    });
    // VPC Endpoints (example for S3 and CloudWatch Logs)
    vpc.addGatewayEndpoint('S3Endpoint', { service: ec2.GatewayVpcEndpointAwsService.S3 });
    vpc.addInterfaceEndpoint('LogsEndpoint', { service: ec2.InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS });

    // ----------------------
    // 2. ECS Cluster and Service Security
    // ----------------------
    const cluster = new ecs.Cluster(this, 'Cluster', { vpc });

    // ----------------------
    // 3. ECS Task Definitions, Roles, Logging, AutoScaling
    // ----------------------
    // IAM roles for ECS tasks (least privilege)
    const ecsTaskExecutionRole = new iam.Role(this, 'ECSTaskExecutionRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AmazonECSTaskExecutionRolePolicy'),
      ],
    });
    const ecsTaskRole = new iam.Role(this, 'ECSTaskRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      description: 'App-specific permissions (least privilege)',
    });

    const logGroup = new logs.LogGroup(this, 'ECSLogGroup', {
      retention: logs.RetentionDays.ONE_WEEK,
    });

    // SSO Task
    const ssoTaskDef = new ecs.FargateTaskDefinition(this, 'SsoTaskDef', {
      cpu: 4096,
      memoryLimitMiB: 8192,
      executionRole: ecsTaskExecutionRole,
      taskRole: ecsTaskRole,
    });
    ssoTaskDef.addContainer('SsoContainer', {
      image: ecs.ContainerImage.fromRegistry('amazon/amazon-ecs-sample'),
      logging: ecs.LogDrivers.awsLogs({ streamPrefix: 'sso', logGroup }),
      portMappings: [{ containerPort: 80 }],
      healthCheck: { command: ['CMD-SHELL', 'curl -f http://localhost/api/sso/health || exit 1'] },
    });

    // Operations Task
    const operationsTaskDef = new ecs.FargateTaskDefinition(this, 'OperationsTaskDef', {
      cpu: 4096,
      memoryLimitMiB: 8192,
      executionRole: ecsTaskExecutionRole,
      taskRole: ecsTaskRole,
    });
    operationsTaskDef.addContainer('OperationsContainer', {
      image: ecs.ContainerImage.fromRegistry('amazon/amazon-ecs-sample'),
      logging: ecs.LogDrivers.awsLogs({ streamPrefix: 'operations', logGroup }),
      portMappings: [{ containerPort: 80 }],
      healthCheck: { command: ['CMD-SHELL', 'curl -f http://localhost/api/operations/health || exit 1'] },
    });

    // Security group for ECS services
    const ecsSg = new ec2.SecurityGroup(this, 'ECSSg', { vpc });
    ecsSg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(80), 'Allow ALB');

    // Fargate Services with placement
    const ssoService = new ecs.FargateService(this, 'SsoService', {
      cluster,
      taskDefinition: ssoTaskDef,
      desiredCount: 1,
      assignPublicIp: false,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      securityGroups: [ecsSg],
      healthCheckGracePeriod: cdk.Duration.seconds(60),
      enableExecuteCommand: true,
    });
    const operationsService = new ecs.FargateService(this, 'OperationsService', {
      cluster,
      taskDefinition: operationsTaskDef,
      desiredCount: 1,
      assignPublicIp: false,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      securityGroups: [ecsSg],
      healthCheckGracePeriod: cdk.Duration.seconds(60),
      enableExecuteCommand: true,
    });
    // Auto-scaling
    const scaling = ssoService.autoScaleTaskCount({ minCapacity: 1, maxCapacity: 3 });
    scaling.scaleOnCpuUtilization('CpuScaling', { targetUtilizationPercent: 70 });

    // ----------------------
    // 4. Application Load Balancer - Security, Logging, WAF
    // ----------------------
    // Security group for ALB
    const albSg = new ec2.SecurityGroup(this, 'ALBSg', { vpc });
    albSg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443), 'Allow HTTPS from CloudFront');
    albSg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(80), 'Allow HTTP from CloudFront');

    // S3 bucket for ALB logs (placeholder)
    const albLogsBucket = new s3.Bucket(this, 'ALBLogsBucket', {
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
    });

    const alb = new elbv2.ApplicationLoadBalancer(this, 'ALB', {
      vpc,
      internetFacing: false,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      securityGroup: albSg,
    });
    alb.logAccessLogs(albLogsBucket);
    // HTTPS listener (self-signed for demo, use ACM in prod)
    const httpsListener = alb.addListener('HttpsListener', {
      port: 443,
      certificates: [elbv2.ListenerCertificate.fromArn('arn:aws:acm:region:account:certificate/cert-id')], // placeholder
      sslPolicy: elbv2.SslPolicy.RECOMMENDED,
      open: true,
    });
    // Path-based routing
    httpsListener.addTargets('SsoTarget', {
      priority: 10,
      pathPatterns: ['/api/sso/*'],
      port: 80,
      targets: [ssoService],
      healthCheck: { path: '/api/sso/health' },
    });
    httpsListener.addTargets('OperationsTarget', {
      priority: 20,
      pathPatterns: ['/api/operations/*'],
      port: 80,
      targets: [operationsService],
      healthCheck: { path: '/api/operations/health' },
    });
    // WAF (placeholder)
    // const waf = new waf.CfnWebACL(...)

    // ----------------------
    // 5. Lambda Functions - Security, Logging, DLQ, VPC
    // ----------------------
    const lambdaLogGroup = new logs.LogGroup(this, 'LambdaLogGroup', {
      retention: logs.RetentionDays.ONE_WEEK,
    });
    const lambdaSg = new ec2.SecurityGroup(this, 'LambdaSg', { vpc });
    lambdaSg.addEgressRule(ec2.Peer.anyIpv4(), ec2.Port.allTraffic());
    // DLQ for event-driven lambdas
    const dlq = new sqs.Queue(this, 'LambdaDLQ', { retentionPeriod: cdk.Duration.days(14) });

    const lambdas: lambda.Function[] = [];
    for (let i = 1; i <= 10; i++) {
      lambdas.push(new lambda.Function(this, `Lambda${i}`, {
        runtime: lambda.Runtime.NODEJS_18_X,
        handler: 'index.handler',
        code: lambda.Code.fromInline('exports.handler = async () => { return { statusCode: 200, body: "ok" }; };'),
        vpc,
        vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
        securityGroups: [lambdaSg],
        memorySize: 256,
        timeout: cdk.Duration.seconds(10),
        logRetention: logs.RetentionDays.ONE_WEEK,
        deadLetterQueue: dlq,
        reservedConcurrentExecutions: i === 10 ? 1 : undefined, // example: restrict concurrency for Lambda10
        environment: { LOG_LEVEL: 'info' },
        role: new iam.Role(this, `LambdaRole${i}`, {
          assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
          managedPolicies: [iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')],
          description: 'Least privilege for Lambda',
        }),
      }));
    }

    // ----------------------
    // 6. API Gateway - Security, Throttling, Auth, Logging
    // ----------------------
    const api = new apigw.RestApi(this, 'ApiGateway', {
      restApiName: 'ServiceApi',
      deployOptions: {
        stageName: 'v1',
        throttlingRateLimit: 10,
        throttlingBurstLimit: 20,
        loggingLevel: apigw.MethodLoggingLevel.INFO,
        dataTraceEnabled: true,
        metricsEnabled: true,
      },
      endpointTypes: [apigw.EndpointType.REGIONAL],
      defaultMethodOptions: {
        authorizationType: apigw.AuthorizationType.COGNITO,
        authorizer: { authorizerId: 'cognito-authorizer-id' } as any, // Placeholder, replace as needed
      },
      policy: new iam.PolicyDocument({
        statements: [
          new iam.PolicyStatement({
            actions: ['execute-api:Invoke'],
            effect: iam.Effect.ALLOW,
            principals: [new iam.ArnPrincipal('arn:aws:iam::cloudfront:user/CloudFront Origin Access Identity E2ABCDEFGHIJKL')], // Placeholder
            resources: ['*'],
          }),
        ],
      }),
    });
    for (let i = 1; i <= 8; i++) {
      const resource = api.root.addResource(`api${i}`);
      resource.addMethod('GET', new apigw.LambdaIntegration(lambdas[i - 1]), {
        authorizationType: apigw.AuthorizationType.COGNITO,
        apiKeyRequired: true,
        requestValidatorOptions: {
          validateRequestBody: false,
          validateRequestParameters: true,
        },
      });
    }
    // Usage plan and API key
    const plan = api.addUsagePlan('UsagePlan', {
      name: 'DefaultUsagePlan',
      throttle: { rateLimit: 10, burstLimit: 20 },
    });
    const apiKey = api.addApiKey('ApiKey');
    plan.addApiKey(apiKey);
    plan.addApiStage({ stage: api.deploymentStage });

    // ----------------------
    // 7. SQS FIFO Queue for Lambda 9
    // ----------------------
    const queue = new sqs.Queue(this, 'FifoQueue', {
      fifo: true,
      queueName: 'queue_1.fifo',
    });
    lambdas[8].addEventSourceMapping('SQSEventSource', {
      eventSourceArn: queue.queueArn,
      batchSize: 1,
      enabled: true,
      retryAttempts: 2,
      onFailure: new lambda.SqsDlq(dlq),
    });
    queue.grantConsumeMessages(lambdas[8]);

    // ----------------------
    // 8. Lambda 10 - Scheduled (cron)
    // ----------------------
    const rule = new events.Rule(this, 'DailyRule', {
      schedule: events.Schedule.cron({ minute: '0', hour: '20' }), // 2am IST = 20:30 UTC previous day
    });
    rule.addTarget(new targets.LambdaFunction(lambdas[9]));

    // 10. CloudFront Distribution
    const cf = new cloudfront.Distribution(this, 'CloudFront', {
      defaultBehavior: {
        origin: new origins.LoadBalancerV2Origin(alb),
        allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
        cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
      },
      additionalBehaviors: {
        'api/sso/*': {
          origin: new origins.LoadBalancerV2Origin(alb),
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        },
        'api/operations/*': {
          origin: new origins.LoadBalancerV2Origin(alb),
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        },
        'api/v1/*': {
          origin: new origins.HttpOrigin(`${api.restApiId}.execute-api.${cdk.Stack.of(this).region}.${cdk.Stack.of(this).urlSuffix}`),
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        },
      },
    });
  }
}
