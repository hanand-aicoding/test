# Spring Batch Service

## Project Overview
A Spring Batch service for processing files from AWS S3, merging, and uploading to multiple cloud storage platforms.

## Prerequisites
- Java 17
- Maven
- AWS S3 Credentials
- Google Cloud Credentials
- PostgreSQL Database
- Redis Cache

## Configuration
1. Configure `application.properties`:
   - AWS S3 Credentials
   - Google Cloud Credentials
   - Database Connection
   - Redis Connection

## Authentication
- Uses Google OAuth2 for authentication
- Stores user sessions in PostgreSQL
- Caches tokens in Redis

## Batch Process Steps
1. Read files from S3 Bucket 1
2. Merge files up to 20MB
3. Compress merged files
4. Upload to S3 Bucket 2 and Google Cloud Storage

## API Endpoints
- `/api/auth/login`: Google Cloud Authentication
- `/api/auth/logout`: User Logout
- `/api/batch/start`: Start Batch Process
- `/api/batch/pause`: Pause Batch Process
- `/api/batch/stop`: Stop Batch Process

## Running the Application
```bash
mvn spring-boot:run
```

## Build and Package
```bash
mvn clean package
```
