package com.batchservice.controller;

import com.batchservice.service.DatabaseService;
import com.batchservice.service.RedisService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {

    @Mock
    private DatabaseService databaseService;

    @Mock
    private RedisService redisService;

    @InjectMocks
    private AuthController authController;

    private OAuth2AuthenticationToken mockAuthentication;

    @BeforeEach
    void setUp() {
        // Create mock OAuth2 authentication
        OAuth2User oauth2User = mock(OAuth2User.class);
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("sub", "test-user-id");
        attributes.put("email", "test@example.com");
        attributes.put("name", "Test User");

        when(oauth2User.getAttributes()).thenReturn(attributes);

        mockAuthentication = mock(OAuth2AuthenticationToken.class);
        when(mockAuthentication.getPrincipal()).thenReturn(oauth2User);
        when(mockAuthentication.getCredentials()).thenReturn(mock(OAuth2User.class));
    }

    @Test
    void login_withValidAuthentication_shouldReturnSuccessResponse() {
        // When
        ResponseEntity<String> response = authController.login(mockAuthentication);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo("Login successful");
    }

    @Test
    void login_withInvalidAuthentication_shouldReturnBadRequest() {
        // Given
        Authentication invalidAuth = mock(Authentication.class);

        // When
        ResponseEntity<String> response = authController.login(invalidAuth);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isEqualTo("Authentication failed");
    }
}
