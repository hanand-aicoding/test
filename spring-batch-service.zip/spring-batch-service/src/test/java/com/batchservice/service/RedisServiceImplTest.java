package com.batchservice.service;

import com.batchservice.service.impl.RedisServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.concurrent.TimeUnit;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class RedisServiceImplTest {

    @Mock
    private RedisTemplate<String, String> redisTemplate;

    @Mock
    private ValueOperations<String, String> valueOperations;

    @InjectMocks
    private RedisServiceImpl redisService;

    private static final String TEST_KEY = "test-key";
    private static final String TEST_TOKEN = "test-token";

    @BeforeEach
    void setUp() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    }

    @Test
    void storeToken_shouldStoreTokenWithExpiration() {
        // Execute
        redisService.storeToken(TEST_KEY, TEST_TOKEN);

        // Verify
        verify(valueOperations).set(
            eq(TEST_KEY), 
            eq(TEST_TOKEN), 
            eq(24L), 
            eq(TimeUnit.HOURS)
        );
    }

    @Test
    void retrieveToken_shouldReturnStoredToken() {
        // Prepare
        when(valueOperations.get(TEST_KEY)).thenReturn(TEST_TOKEN);

        // Execute
        String retrievedToken = redisService.retrieveToken(TEST_KEY);

        // Verify
        assertThat(retrievedToken).isEqualTo(TEST_TOKEN);
        verify(valueOperations).get(TEST_KEY);
    }

    @Test
    void deleteToken_shouldDeleteTokenFromRedis() {
        // Execute
        redisService.deleteToken(TEST_KEY);

        // Verify
        verify(redisTemplate).delete(TEST_KEY);
    }
}
