package com.batchservice.service;

import com.batchservice.model.UserSession;
import com.batchservice.repository.UserSessionRepository;
import com.batchservice.service.impl.DatabaseServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DatabaseServiceImplTest {

    @Mock
    private UserSessionRepository userSessionRepository;

    @InjectMocks
    private DatabaseServiceImpl databaseService;

    private UserSession testUserSession;

    @BeforeEach
    void setUp() {
        testUserSession = new UserSession();
        testUserSession.setUserId("test-user-id");
        testUserSession.setEmail("test@example.com");
        testUserSession.setName("Test User");
        testUserSession.setLoginTime(LocalDateTime.now());
    }

    @Test
    void saveUserSession_shouldSaveSuccessfully() {
        // When
        databaseService.saveUserSession(testUserSession);

        // Then
        verify(userSessionRepository).save(testUserSession);
    }

    @Test
    void getUserSession_whenUserExists_shouldReturnUserSession() {
        // Given
        when(userSessionRepository.findByUserId("test-user-id"))
            .thenReturn(Optional.of(testUserSession));

        // When
        UserSession retrievedSession = databaseService.getUserSession("test-user-id");

        // Then
        assertThat(retrievedSession).isEqualTo(testUserSession);
    }

    @Test
    void getUserSession_whenUserNotExists_shouldThrowException() {
        // Given
        when(userSessionRepository.findByUserId("non-existent-id"))
            .thenReturn(Optional.empty());

        // Then
        assertThatThrownBy(() -> databaseService.getUserSession("non-existent-id"))
            .isInstanceOf(RuntimeException.class)
            .hasMessageContaining("User session not found");
    }

    @Test
    void deleteUserSession_shouldDeleteSuccessfully() {
        // When
        databaseService.deleteUserSession("test-user-id");

        // Then
        verify(userSessionRepository).deleteByUserId("test-user-id");
    }
}
