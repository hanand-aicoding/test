package com.batchservice.repository;

import com.batchservice.model.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserSessionRepository extends JpaRepository<UserSession, Long> {
    /**
     * Find user session by user ID
     * @param userId Unique user identifier
     * @return Optional of UserSession
     */
    Optional<UserSession> findByUserId(String userId);

    /**
     * Delete user session by user ID
     * @param userId Unique user identifier
     */
    void deleteByUserId(String userId);
}
