package com.batchservice.service;

public interface RedisService {
    /**
     * Store token in Redis
     * @param key Unique key for the token
     * @param token Authentication token
     */
    void storeToken(String key, String token);

    /**
     * Retrieve token from Redis
     * @param key Unique key for the token
     * @return Authentication token
     */
    String retrieveToken(String key);

    /**
     * Delete token from Redis
     * @param key Unique key for the token
     */
    void deleteToken(String key);
}
