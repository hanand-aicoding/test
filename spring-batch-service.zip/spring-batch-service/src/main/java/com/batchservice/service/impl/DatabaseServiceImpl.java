package com.batchservice.service.impl;

import com.batchservice.model.UserSession;
import com.batchservice.repository.UserSessionRepository;
import com.batchservice.service.DatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DatabaseServiceImpl implements DatabaseService {
    @Autowired
    private UserSessionRepository userSessionRepository;

    @Override
    @Transactional
    public void saveUserSession(UserSession userSession) {
        userSessionRepository.save(userSession);
    }

    @Override
    @Transactional(readOnly = true)
    public UserSession getUserSession(String userId) {
        return userSessionRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User session not found"));
    }

    @Override
    @Transactional
    public void deleteUserSession(String userId) {
        userSessionRepository.deleteByUserId(userId);
    }
}
