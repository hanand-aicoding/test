package com.batchservice.service.impl;

import com.batchservice.service.S3Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.S3Object;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class S3ServiceImpl implements S3Service {
    @Autowired
    private S3Client s3Client;

    @Value("${aws.s3.source-bucket}")
    private String sourceBucket;

    @Override
    public List<File> listFilesByDateRange(String bucketName, LocalDate startDate, LocalDate endDate) {
        ListObjectsV2Request request = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();

        return s3Client.listObjectsV2(request).contents().stream()
                .map(S3Object::key)
                .filter(key -> isInDateRange(key, startDate, endDate))
                .map(this::downloadFile)
                .collect(Collectors.toList());
    }

    @Override
    public void mergeFiles(List<File> files, File outputFile, long maxSizeBytes) {
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            for (File file : files) {
                byte[] fileContent = Files.readAllBytes(file.toPath());
                fos.write(fileContent);

                if (outputFile.length() >= maxSizeBytes) {
                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error merging files", e);
        }
    }

    @Override
    public void compressToZip(List<File> files, File zipFile) {
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            for (File file : files) {
                ZipEntry zipEntry = new ZipEntry(file.getName());
                zos.putNextEntry(zipEntry);
                
                byte[] bytes = Files.readAllBytes(file.toPath());
                zos.write(bytes, 0, bytes.length);
                zos.closeEntry();
            }
        } catch (IOException e) {
            throw new RuntimeException("Error creating zip file", e);
        }
    }

    @Override
    public String uploadFile(String bucketName, File file) {
        // Implement S3 file upload logic
        return null; // Placeholder
    }

    private boolean isInDateRange(String key, LocalDate startDate, LocalDate endDate) {
        // Implement date range filtering based on file key/path
        return true; // Placeholder
    }

    private File downloadFile(String key) {
        // Implement file download from S3
        return null; // Placeholder
    }
}
