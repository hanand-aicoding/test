package com.batchservice.service;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

public interface S3Service {
    /**
     * List files from S3 bucket within a specific date range
     * @param bucketName Source bucket name
     * @param startDate Start date for file retrieval
     * @param endDate End date for file retrieval
     * @return List of files matching the date range
     */
    List<File> listFilesByDateRange(String bucketName, LocalDate startDate, LocalDate endDate);

    /**
     * Merge files up to a specified max size
     * @param files List of files to merge
     * @param outputFile Merged output file
     * @param maxSizeBytes Maximum size of merged file in bytes
     */
    void mergeFiles(List<File> files, File outputFile, long maxSizeBytes);

    /**
     * Compress files into a zip
     * @param files Files to compress
     * @param zipFile Output zip file
     */
    void compressToZip(List<File> files, File zipFile);

    /**
     * Upload file to S3 bucket
     * @param bucketName Destination bucket
     * @param file File to upload
     * @return Upload URL or key
     */
    String uploadFile(String bucketName, File file);
}
