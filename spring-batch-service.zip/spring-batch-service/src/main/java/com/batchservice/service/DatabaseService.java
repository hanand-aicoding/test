package com.batchservice.service;

import com.batchservice.model.UserSession;

public interface DatabaseService {
    /**
     * Save user session details
     * @param userSession User session information
     */
    void saveUserSession(UserSession userSession);

    /**
     * Retrieve user session by user ID
     * @param userId Unique user identifier
     * @return UserSession details
     */
    UserSession getUserSession(String userId);

    /**
     * Delete user session
     * @param userId Unique user identifier
     */
    void deleteUserSession(String userId);
}
