package com.batchservice.batch;

import com.batchservice.service.S3Service;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
    @Autowired
    private S3Service s3Service;

    @Bean
    public Job dataProcessingJob(JobRepository jobRepository, 
                                 Step readFromS3Step, 
                                 Step mergeFilesStep, 
                                 Step uploadToCloudStep) {
        return new JobBuilder("dataProcessingJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(readFromS3Step)
                .next(mergeFilesStep)
                .next(uploadToCloudStep)
                .build();
    }

    @Bean
    public Step readFromS3Step(JobRepository jobRepository, 
                                PlatformTransactionManager transactionManager) {
        return new StepBuilder("readFromS3Step", jobRepository)
                .tasklet(new S3FileReaderTasklet(), transactionManager)
                .build();
    }

    @Bean
    public Step mergeFilesStep(JobRepository jobRepository, 
                                PlatformTransactionManager transactionManager) {
        return new StepBuilder("mergeFilesStep", jobRepository)
                .tasklet(new FileMergeTasklet(), transactionManager)
                .build();
    }

    @Bean
    public Step uploadToCloudStep(JobRepository jobRepository, 
                                   PlatformTransactionManager transactionManager) {
        return new StepBuilder("uploadToCloudStep", jobRepository)
                .tasklet(new CloudUploadTasklet(), transactionManager)
                .build();
    }
}
