package com.batchservice.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/batch")
public class BatchController {
    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job dataProcessingJob;

    @PostMapping("/start")
    public ResponseEntity<String> startBatch(
            @RequestParam LocalDate startDate, 
            @RequestParam LocalDate endDate) {
        try {
            JobParameters jobParameters = new JobParametersBuilder()
                    .addLocalDate("startDate", startDate)
                    .addLocalDate("endDate", endDate)
                    .toJobParameters();
            
            jobLauncher.run(dataProcessingJob, jobParameters);
            return ResponseEntity.ok("Batch job started successfully");
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body("Failed to start batch job: " + e.getMessage());
        }
    }

    @PostMapping("/pause")
    public ResponseEntity<String> pauseBatch() {
        // Implement pause logic
        return ResponseEntity.ok("Batch job paused");
    }

    @PostMapping("/stop")
    public ResponseEntity<String> stopBatch() {
        // Implement stop logic
        return ResponseEntity.ok("Batch job stopped");
    }
}
