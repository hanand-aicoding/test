package com.batchservice.controller;

import com.batchservice.model.UserSession;
import com.batchservice.service.DatabaseService;
import com.batchservice.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private DatabaseService databaseService;

    @Autowired
    private RedisService redisService;

    @GetMapping("/login")
    public ResponseEntity<String> login(Authentication authentication) {
        if (authentication instanceof OAuth2AuthenticationToken) {
            OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
            Map<String, Object> attributes = oauthToken.getPrincipal().getAttributes();

            UserSession userSession = new UserSession();
            userSession.setUserId((String) attributes.get("sub"));
            userSession.setEmail((String) attributes.get("email"));
            userSession.setName((String) attributes.get("name"));
            userSession.setLoginTime(LocalDateTime.now());
            userSession.setAccessToken(oauthToken.getCredentials().getTokenValue());

            // Save user session to database
            databaseService.saveUserSession(userSession);

            // Store token in Redis
            redisService.storeToken(userSession.getUserId(), userSession.getAccessToken());

            return ResponseEntity.ok("Login successful");
        }
        return ResponseEntity.badRequest().body("Authentication failed");
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(Authentication authentication) {
        if (authentication instanceof OAuth2AuthenticationToken) {
            String userId = authentication.getName();

            // Delete user session from database
            databaseService.deleteUserSession(userId);

            // Remove token from Redis
            redisService.deleteToken(userId);

            return ResponseEntity.ok("Logout successful");
        }
        return ResponseEntity.badRequest().body("Logout failed");
    }
}
